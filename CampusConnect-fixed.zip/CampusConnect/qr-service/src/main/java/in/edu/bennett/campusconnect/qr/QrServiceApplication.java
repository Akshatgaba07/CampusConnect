package in.edu.bennett.campusconnect.qr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QrServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(QrServiceApplication.class, args);
    }
}
